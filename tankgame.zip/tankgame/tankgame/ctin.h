#ifndef _CTIN_H
#define _CTIN_H
#define _CRT_SECURE_NO_WARNINGS
#include <unordered_map>
#include <map>
#include <cmath>
#include <bits/stdc++.h>
#include <SFML/Graphics.hpp>
#include <time.h>
#include <thread>
#include <chrono>   
#define E "\n"
using namespace std;
using namespace sf;
struct Point{int x,y;};
const int width = 30,height = 30;
#endif // _CTIN_H




